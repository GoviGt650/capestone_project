// Base URL → NGINX (Docker)
window.BASE_URL = "http://backend-alb-943964116.eu-north-1.elb.amazonaws.com";

// Single API endpoint - Nginx handles all routing and load balancing
window.API = `${window.BASE_URL}/api`;

console.log("🌐 API configured:", window.API);
console.log("⚖️ Load balancing via Nginx round-robin");